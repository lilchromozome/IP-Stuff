#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <assert.h>
#include "ppm_io.h"
#include "puzzle.h"

int main(int argc, char **argv) {
  if (argc < 1 || argc > 2) {
    fprintf(stderr, "Usage: ./puzzle [<command file>]\n");
    return 1;
  }
  char command;
  int input = 0;
  int size = 0;
  int * order = NULL;
  char * filename = malloc(sizeof(char) * 255);
  char * puzzle_image = malloc(sizeof(char) * 255);
  char * config = malloc(sizeof(char) * 255);
  char direction;
  int numInversions;

  FILE *fp = fopen(argv[1],"r");
  FILE *img;                                        //in I
  FILE *p_img;                                      //in W
  FILE *conf;
  Puzzle *p;

  do {
    if((input = fscanf(fp, " %c", &command)) == EOF){
        return 0;};
    switch (command){

      /* Quit program */
      case 'Q':
        return 0;

      /* Create initial puzzle with size rows and columns */
      case 'C':
        printf("C\n");
        // error handling: size is not an integer from [2,20]
        if (fscanf(fp, "%d", &size) != 1 || size < 2 || size > 20) {
          fprintf(stderr, "Error: size must be an integer between 2 and 20.\n");
          exit(1);
        }

        handle_C_command(&p, size);

        break;
      /*	Initialize puzzle configuration with series of tile numbers */
      case 'T':
      printf("T\n");
        order = malloc(sizeof(int) * size * size);
        for(int i = 0; i < size * size; i++){
          fscanf(fp, " %d", order+i);
        }
        handle_T_command(p, order);
        break;

      /* Load the background image from specified PPM file */
      case 'I':
      printf("I\n");
        fscanf(fp, " %s", filename);
        printf("%s\n", filename);
        img = fopen(filename, "r");
        if(img == NULL){
          fprintf(stderr, "Invalid input\n");
          exit(1);
        }
        handle_I_command(img, p, order);
        break;

      /* Print sequence of tile numbers reflecting current puzzle configuration */
      case 'P':
      printf("P\n");
        //implement
        handle_P_command(p);
        break;

      /* Write puzzle image to puzzle_image and puzzle configuration to config */
      case 'W':
        printf("W\n");

        fscanf(fp, " %s", puzzle_image);
        printf("%s\n", puzzle_image);
        p_img = fopen(puzzle_image, "w");

        fscanf(fp, " %s", config);
        printf("%s\n", config);
        conf = fopen(config, "w");

        // error condition: files don't open correctly
        if (p_img == NULL) {
          fprintf(stderr, "Error: could not open puzzle_image file.\n");
          exit(1);
        }
    
        if (conf == NULL) {
          fprintf(stderr, "Error: could not open config file\n");
          exit(1);
        }
        printf("%d, %d\n", p->tiles->index, p->tiles->tile->rows);
        handle_W_command(p, p_img, conf);

        //implement
        break;

      /* Slide a free tile in specified direction */
      case 'S':
        // printf("S\n");
        fscanf(fp, " %c", &direction); // test
        printf("%c\n", direction);
        handle_S_command(p, direction); 

      /* 	Check to see whether the puzzle is in the “winning” configuration */
      case 'K':
        //implement
        break;

      /* Compute a series of moves to solve the puzzle */
      case 'V':
        numInversions = countNumInversions(order, size);
        if (numInversions % 2 == 1) {
          fprintf(stdout, "No solution found.\n"); // not solvable
        } else {
          //  handle_V_command(p, order); // solvable
        }

        break;
      
        
      //error handling
      default: fprintf(stderr, "Invalid command\n");
          return 3;
      }
  }while(input == 1);

  for(int i = 0; i < size * size; i++){
    
  }

  fclose(p_img);
  fclose(conf);
  fclose(fp);
  free(puzzle_image);
  free(config);
  free(order);
  free(filename);
}
