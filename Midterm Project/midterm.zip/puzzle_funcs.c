#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "ppm_io.h"
#include "puzzle.h"

/*
Function creates a new Puzzle struct of the specified size.

@param int size: size of the Puzzle struct 
return pointer to a new Puzzle struct
*/
Puzzle *puzzle_create(int size){
  Puzzle * puzzle = (Puzzle *) malloc(sizeof(Puzzle));
  assert(puzzle); //confirm malloc didn't fail
    
  puzzle -> size = size;
  puzzle -> image = NULL;
  puzzle -> tiles = calloc(size * size, sizeof(Tile));
  for(int i = 0; i < size * size; i++){
    puzzle -> tiles[i].index = 0;
  }
  return puzzle;
}

/*
Function that destroys a Puzzle struct by freeing its memory.

@param *p: pointer to a Puzzle structure
return void
*/
void puzzle_destroy(Puzzle *p){
    for(int i = 0; i < p->size * p->size; i++){
        free(p->tiles[i].tile);
    }
    free(p);
}

/*
Function to handle the C (create) command by calling puzzle_create.

@param *p: pointer to a Puzzle structure 
@param int size: size of the Puzzle struct 

return 1 if successfully created, 0 else
*/
int handle_C_command(Puzzle **p, int size){
    *p = puzzle_create(size);
    if(*p){
        return 1;
        }
    return 0;
}

/*
Function to handle the T (tile) command by initializing puzzle configuration with series of tile numbers.

@param *p: pointer to a Puzzle structure 
@param *order: pointer to an integer array

return 1 if both pointers are not null, 0 else
*/
int handle_T_command(Puzzle *p, int *order){
    if(p && order){
        for(int i = 0; i < (int) sizeof(*order)/sizeof(int);i++ ){
            p->tiles[i].index = *(order+i);
        }
        return 1;
    }
    return 0;
}

/*
Function to handle the I (image) command by reading the image file.

@param *in: pointer to a file for the input image
@param *p: pointer to a Puzzle structure 
@param *order: pointer to an integer array

return 1 if both pointers are not null, 0 else
*/
int handle_I_command(FILE *in, Puzzle *p, int *order){
    if(p && in){
        p->image = ReadPPM(in);
        for (int i = 0; i < p->size; i++){
            for (int j = 0; j < p->size; j++){
                puzzle_create_tile(p, i, j, order[i*p->size+j]);
                // printf("%d %d %d\n", p->tiles->tile->data[i*p->size+j].r, p->tiles->tile->data[i*p->size+j].g, p->tiles->tile->data[i*p->size+j].b);
            }
        }
        return 1;
    }
    return 0;
}

/*
Function to handle the P (print) command by printing the sequence of tile numbers reflecting current puzzle configuration.

@param *p: pointer to a Puzzle structure 
return 1 if the pointers is not null, 0 else
*/
int handle_P_command(Puzzle *p){
    int s = p->size;
    if(p){
        for(int i = 0; i < s*s; i++){
            printf("%d ", p->tiles[i].index);
        }
        return 1;
    }
    return 0;
}

/*
Function to print the specified tile of the solved image.

@param *p: pointer to a Puzzle structure 
@param *image: pointer to a file for the input image
@param int row: row of tile to be printed
@param int col: column of tile to be printed

return void
*/
void print_tile(Puzzle *p, FILE * image, int row, int col){
    Tile * t = puzzle_get_tile(p , row, col);

    Image *img;                                                        
    img = malloc(sizeof(Image));
    img->data = malloc(sizeof(Pixel) * t->tile->cols * t->tile->rows);
    img->rows = p->tiles->tile->rows;
    img->cols = p->tiles->tile->cols;

    for(int x = 0; x < t->tile->rows; x++){                  //rows of  pixels in tile
        int tile_pos = x * t->tile->cols;
        for(int y = 0; y < t->tile->cols; y++){                     //cols of pixels in tile 
            Pixel pix = t->tile->data[tile_pos + y];
            // printf("%d %d\n", tile_pos + y, t->tile->data[tile_pos + y].r);
            img->data[tile_pos + y] = pix;
            // printf("img:%d, tile: %d\n", (img->data+tile_pos)->g, (t->tile->data+tile_pos)->g);
        }
    }
    // printf("%d %d\n", img->rows, img->cols);
    WritePPM(image, img);
}


/*
Create a tile in puzzle at [row][col] with t->tile = value

col and row are by index, start with row 0 column 0 in top right
p is the puzzle that is being passed (solved or unsolved)
value is the number of the tile
*/
Tile * puzzle_create_tile(Puzzle *p, int row, int col, int value){
    // int puzzle_pixels = p->image->rows * p->image->cols;                               //get num pixels in puzzle

    //set up new tile
    Tile * t = (Tile*) malloc(sizeof(Tile));                                  //create a new tile
    t->tile = (Image*) malloc(sizeof(Image));                        //create a new image for that tile

    // int tile_pixels = puzzle_pixels / (p->size * p->size);  //num pixels in whole tile
    int tile_row_pixels = p->image->rows / p->size;         //num pixels in tile row
    int tile_col_pixels = p->image->cols / p->size;         //num pixels in tile col
    t->tile->rows = tile_row_pixels;
    t->tile->cols = tile_col_pixels;

    t->tile->data = malloc(sizeof(Pixel) * tile_col_pixels * tile_row_pixels);                           //allocate memory for the image of that tile
    // int index = p->size * row + col;                                                    //calculate the index of the tile based on col/row
    t->index = value;
    p->tiles[row * p->size + col] = *t;
    // printf("row: %d col: %d ind: %d\n", row, col, t->index);                                                      

    //calculate which part of the puzzle go to which tile
    for(int r = 0; r < tile_row_pixels; r++){
        int puzzle_read = (row * tile_row_pixels + r) * p->image->cols + col * tile_col_pixels;
        int tile_write = r * tile_col_pixels;
        for(int c = 0; c < tile_col_pixels; c++){
            t->tile->data[tile_write + c]= p->image->data[puzzle_read + c];          //copies image pixel to tile data
        }
    }
    return t;
}
/*
returns the tile that is at [row][col]
col and row are not by index, start with row 0 column 0 in top right
*/
Tile * puzzle_get_tile(const Puzzle *p, int row , int col){
    int num = p->size * row + col;
    return &p->tiles[num];
}

/*
config is the order of tiles, image is the image that config creates
p contains unscrambled image
config is taken from T
image should be output with scrambled image
*/
int handle_W_command(Puzzle *p, FILE *image, FILE *config){
    int num_pixels = p->image->rows * p->image->cols;

    //create new image
    Image *img;                                                        
    img = malloc(sizeof(Image));
    img->data = malloc(sizeof(Pixel) * num_pixels);
    img->rows = p->image->rows;
    img->cols = p->image->cols;

    //write tile order to config
    for(int i = 0; i < p->size * p->size; i++){
        fprintf(config, " %d", p->tiles[i].index);
    }

    // //write pixels to image
    for(int i = 0; i < p->size; i++){                                   //rows of tiles
        for(int x = 0; x < p->tiles->tile->rows; x++){                  //rows of pixels in tile
            for(int j = 0; j < p->size; j++){                           //cols of tiles

                int row = (p->tiles[i * p->size +j].index -1) / p->size;
                int col = (p->tiles[i * p->size +j].index -1) % p->size;     //finds row/col of next tile

                if(p->tiles[i * p->size +j].index == 0){
                    row = p->size - 1;
                    col = p->size -1;
                }
                
                // printf("p->tiles index %d: ", p->tiles[i * p->size +j].index);
                
                Tile * t = puzzle_get_tile(p, row, col);                //get tile
                // printf("r:%d c:%d i:%d \n", row, col, t->index);
                int img_pos = (i * img->cols * t->tile->rows) + x * img->cols + j * t->tile->rows;          //calculate where in rows pixel start copying is
                int tile_pos = x * t->tile->cols;
                // printf("%d\n", img_pos);

                /* make 0 tile black*/
                if(p->tiles[i * p->size +j].index == 0){
                    // printf("%d, %d\n", img_pos, tile_pos);
                    for(int y = 0; y < t->tile->cols; y++){                     //cols of pixels in tile
                    Pixel pix = t->tile->data[tile_pos + y];
                    pix.r = 0;
                    pix.g = 0;
                    pix.b = 0;
                    img->data[img_pos+y] = pix;
                    // printf("img: %d, tile %d\n", img->data[img_pos+y].r, t->tile->data[tile_pos + y].r);
                }
                }
                else{
                    // printf("img: %d, tile: %d\n", img_pos, tile_pos);
                    for(int y = 0; y < t->tile->cols; y++){                     //cols of pixels in tile
                        Pixel pix = t->tile->data[tile_pos + y];
                        img->data[img_pos+y] = pix;
                        // printf("img: %d, tile %d\n", img->data[img_pos+y].r, t->tile->data[tile_pos + y].r);
                    }
                }
            }
        }
    }
    return WritePPM(image, img);
}

void handle_S_command(Puzzle *p, char direction){
    
    // find empty index
    int order[p->size * p->size];
    for(int i = 0; i < p->size * p->size; i++){
        order[i] = p->tiles[i].index;
    }
    int empty_index = -1;
    for (int i = 0; i < p->size * p->size; i++) {
        if (order[i] == 0) {
        empty_index = i;
        break;
        }
    }

    // check if it can move
    int target_index = -1;
    if (direction == 'd') {
        if (empty_index < p->size * (p->size - 1)+1) {
            target_index = empty_index + p->size;
        }
    } else if (direction == 'r') {
        if (empty_index % p->size < p->size - 1) {
            target_index = empty_index + 1;
        }
    } else if (direction == 'u') {
        if (empty_index > p->size) {
            target_index = empty_index - p->size;
        }
    } else if (direction == 'l') {
        if (empty_index % p->size > 0) {
            target_index = empty_index - 1;
        }
    } else {
        fprintf(stderr, "Error: Did not enter valid direction for sliding.\n");
        exit(1);
    }
    
    // swap values
    if (target_index != -1) {
        Tile * empty = puzzle_get_tile(p, (target_index)/p->size,(target_index)%p->size);
        Tile * target = puzzle_get_tile(p, (target_index)/p->size,(target_index)%p->size);
        p->tiles[target_index] = *empty;
        p->tiles[empty_index] = *target;
    }
}

// FINISH DOCUMENTATION
// file to count the number of inversions in index
int countNumInversions(int * order, int size) {
    int numInversions = 0;

    for(int i = 0; i < size * size - 1; i++) {
        for(int j = i + 1; j < size * size; j++) {
            if(order[i] > order[j] && order[j] != 0)
                numInversions++;
        }
    }
    return numInversions;
}

int handle_K_command(Puzzle * p){
    int order[p->size * p->size];
    int solved;
    for(int i = 0; i < p->size * p->size; i++){
        order[i] = p->tiles[i].index -1;
        if(order[i] < 0){
            order[i] = p->size * p->size -1;
        }
    }
    for(int i = 0; i < p->size * p->size; i++){
        if(order[i] == i){
            solved = 1;
        }
        else{
            solved = 0;
        }
    }
    if(solved){
        printf("Solved\n");
        return 0;
    }
    else{
        printf("Not solved\n");
        return 1;
    }
    return 1;
}
