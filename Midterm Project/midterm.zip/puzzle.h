#ifndef PUZZLE_H
#define PUZZLE_H

#include "ppm_io.h" // for Image data type

typedef struct{
  int index;
  Image * tile;       //pointer to image of tile square
} Tile;

typedef struct {
  int size;
  Image * image;      //pointer to image pf whole puzzle
  Tile * tiles;       //array of tiles
} Puzzle;



// TODO: function declarations
Puzzle *puzzle_create(int size);
void puzzle_destroy(Puzzle *p);
Tile * puzzle_create_tile(Puzzle *p, int row, int col, int value);
Tile * puzzle_get_tile(const Puzzle *p, int row, int col);

void print_tile(Puzzle *p, FILE *image, int row, int col);

int handle_C_command(Puzzle **p, int size);
int handle_T_command(Puzzle *p, int * order);
int handle_P_command(Puzzle *p);
int handle_V_command(Puzzle *p, int *order);
int handle_I_command(FILE *in, Puzzle *p, int *order);
int handle_W_command(Puzzle *p, FILE *image, FILE *config);
void handle_S_command(Puzzle *p, char direction);
int handle_K_command(Puzzle *p);
int countNumInversions(int * order, int size);

#endif // PUZZLE_H
