//William Li
//wli128
#include <stdio.h>

int main(){
    printf("The first prize goes to Jennifer.\n");
    return 0;
}