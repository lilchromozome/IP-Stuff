//William Li
//wli128

#include <stdio.h>

int main(){
    printf("The third prize goes to Pat.\n");
    return 0;
}