//William Li
//wli128

#include <stdio.h>

int main() {
    printf("The second prize goes to Gongqi.\n");
    return 0;
}