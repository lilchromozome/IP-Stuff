#ifndef PLOT_H
#define PLOT_H

#include <vector>
#include <map>
#include <string>
#include "bounds.h"
#include "image.h"
#include "func.h"
#include "fill.h"
#include <memory>

class Plot {
private:
  //Fields to represent plot bounds, functions, fills, colors and image size
  Bounds bounds = Bounds();
  std::vector<Function*> funcs = std::vector<Function*>();
  std::vector<Color> colors = std::vector<Color>();
  std::vector<Fill> fills = std::vector<Fill>();
  double x_dim = 0;
  double y_dim = 0;
  // value semantics are prohibited
  Plot(const Plot &);
  Plot &operator=(const Plot &);


public:
  Plot();
  ~Plot();

  //Member functions to set and modify plot data
  Bounds get_bounds() const;
  int get_width() const;
  int get_height() const;
  const Function& get_func_num(int i) const;
  const Fill& get_fill_num (int i) const;
  Color get_color(int i) const;
  int get_num_funcs() const;
  int get_num_fills() const;
  
  void set_bounds(double xmin, double xmax, double ymin, double ymax);
  void set_dimensions(int x_dim, int y_dim);
  void add_function(const std::string &name, Expr *expr);
  void add_color(const Color color,int pos);
  void add_fill(const Fill fill);

  Function& get_func(std::string name);
  int get_func_pos(std::string name);
  void resize_color(int size);
};

#endif // PLOT_H
